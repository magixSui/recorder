/*
 * @Author: your name
 * @Date: 2020-11-10 16:14:08
 * @LastEditTime: 2020-11-10 16:35:41
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \qc_new_websited:\projects\recorder-front\vue.config.js
 */

module.exports = {
  pages: {
    index: {
      entry: 'src/main.js',
      title: '记牌器'
    }
  },
  // 选项...
  // 例如，如果你的应用被部署在 https://www.my-app.com/my-app/，则设置 publicPath 为 /my-app/。
  publicPath: './'
};
